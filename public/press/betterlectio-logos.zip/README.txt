BETTERLECTIO PRESS KIT
Updated: 3 October 2026

ABOUT
BetterLectio is a free, independent interface for Lectio, created by student
and developer Jonathan Bangert. BetterLectio is available for iOS, Android,
Chrome, Firefox and Edge. It is not affiliated with, endorsed by or operated
by MaCom A/S.

PRESS CONTACT
Jonathan Bangert
betterlectio@jonathanb.dk
https://betterlectio.dk/presse

USAGE
These files may be used for editorial coverage of BetterLectio with the credit
"BetterLectio". Images may be cropped to fit an editorial layout. Do not alter,
redraw or add effects to the BetterLectio logo.

LOGOS
Use the SVG files whenever possible. PNG files are supplied at 1024 x 1024 px.
The black transparent mark is the preferred mark on light backgrounds; use the
white transparent mark on dark backgrounds. Keep clear space around the mark.

PRODUCT IMAGES
The product folders contain original-resolution browser and mobile imagery.
Images in product/web are available both as clean screenshots and presentation-
ready framed versions. Images in product/mobile are portrait campaign artwork
and a wide panorama. Images in product/features are the current selection used
across betterlectio.dk.

CAPTIONS AND CREDITS
Suggested captions are available beside every image at
https://betterlectio.dk/presse. Credit all assets as "BetterLectio".

Need another crop, a founder portrait, video or technical background?
Contact betterlectio@jonathanb.dk.
